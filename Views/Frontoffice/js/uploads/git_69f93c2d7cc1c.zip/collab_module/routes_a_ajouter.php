
<?php
// ─────────────────────────────────────────────────────────────────────────────
// ROUTES À AJOUTER dans le switch($page) de ton index.php existant
// Copie ce bloc et ajoute-le dans le switch, avant le "default:"
// ─────────────────────────────────────────────────────────────────────────────

/*
    case 'collab':
        require_once 'Controller/CollabController.php';
        $controller = new CollabController();

        // ── VIEWS ──
        if ($action === 'group'  && $id)  { $controller->showGroup($id);  }
        elseif ($action === 'repo'   && $id)  { $controller->showRepo($id);   }
        elseif ($action === 'branch' && $id)  { $controller->showBranch($id); }
        elseif ($action === 'commit' && $id)  { $controller->showCommit($id); }

        // ── GROUPS ACTIONS ──
        elseif ($action === 'create-group' && $_SERVER['REQUEST_METHOD'] === 'POST') { $controller->createGroup(); }
        elseif ($action === 'join-group'   && $_SERVER['REQUEST_METHOD'] === 'POST') { $controller->joinGroup();   }
        elseif ($action === 'leave-group'  && $_SERVER['REQUEST_METHOD'] === 'POST') { $controller->leaveGroup();  }
        elseif ($action === 'delete-group' && $_SERVER['REQUEST_METHOD'] === 'POST') { $controller->deleteGroup(); }

        // ── REPOS ACTIONS ──
        elseif ($action === 'create-repo' && $_SERVER['REQUEST_METHOD'] === 'POST') { $controller->createRepo(); }
        elseif ($action === 'delete-repo' && $_SERVER['REQUEST_METHOD'] === 'POST') { $controller->deleteRepo(); }

        // ── BRANCHES ACTIONS ──
        elseif ($action === 'create-branch' && $_SERVER['REQUEST_METHOD'] === 'POST') { $controller->createBranch(); }
        elseif ($action === 'delete-branch' && $_SERVER['REQUEST_METHOD'] === 'POST') { $controller->deleteBranch(); }

        // ── COMMITS ACTIONS ──
        elseif ($action === 'create-commit' && $_SERVER['REQUEST_METHOD'] === 'POST') { $controller->createCommit(); }
        elseif ($action === 'delete-commit' && $_SERVER['REQUEST_METHOD'] === 'POST') { $controller->deleteCommit(); }

        // ── DEFAULT : liste des groupes ──
        else { $controller->listGroups(); }
        break;
*/
?>
