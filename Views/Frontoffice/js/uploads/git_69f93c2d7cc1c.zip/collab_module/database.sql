-- ============================================================
-- FreelaSkill — Module Collaboration & Versioning
-- SQL à exécuter dans phpMyAdmin sur la base "skillswap"
-- ============================================================

-- 1. Groupes
CREATE TABLE IF NOT EXISTS collab_groups (
    id_group      INT AUTO_INCREMENT PRIMARY KEY,
    nom           VARCHAR(100)  NOT NULL,
    description   TEXT,
    id_createur   INT           NOT NULL,
    date_creation DATETIME      NOT NULL DEFAULT NOW(),
    visibilite    ENUM('public','prive') NOT NULL DEFAULT 'public'
);

-- 2. Membres des groupes
CREATE TABLE IF NOT EXISTS collab_group_members (
    id_member   INT AUTO_INCREMENT PRIMARY KEY,
    id_group    INT  NOT NULL,
    id_user     INT  NOT NULL,
    role        ENUM('owner','member') NOT NULL DEFAULT 'member',
    date_joined DATETIME NOT NULL DEFAULT NOW(),
    UNIQUE KEY unique_member (id_group, id_user)
);

-- 3. Dépôts (repositories) par groupe
CREATE TABLE IF NOT EXISTS collab_repositories (
    id_repo        INT AUTO_INCREMENT PRIMARY KEY,
    nom            VARCHAR(100) NOT NULL,
    description    TEXT,
    id_group       INT          NOT NULL,
    id_createur    INT          NOT NULL,
    date_creation  DATETIME     NOT NULL DEFAULT NOW(),
    branche_defaut VARCHAR(50)  NOT NULL DEFAULT 'main'
);

-- 4. Branches par dépôt
CREATE TABLE IF NOT EXISTS collab_branches (
    id_branch     INT AUTO_INCREMENT PRIMARY KEY,
    nom           VARCHAR(100) NOT NULL,
    id_repo       INT          NOT NULL,
    id_createur   INT          NOT NULL,
    date_creation DATETIME     NOT NULL DEFAULT NOW(),
    is_default    TINYINT(1)   NOT NULL DEFAULT 0
);

-- 5. Commits par branche
CREATE TABLE IF NOT EXISTS collab_commits (
    id_commit   INT AUTO_INCREMENT PRIMARY KEY,
    message     VARCHAR(255) NOT NULL,
    id_branch   INT          NOT NULL,
    id_auteur   INT          NOT NULL,
    date_commit DATETIME     NOT NULL DEFAULT NOW(),
    contenu     LONGTEXT     NOT NULL,
    nom_fichier VARCHAR(255) NOT NULL DEFAULT 'fichier.txt',
    langage     VARCHAR(30)  NOT NULL DEFAULT 'text'
);
