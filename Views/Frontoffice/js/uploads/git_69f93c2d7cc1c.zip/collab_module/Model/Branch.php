<?php
/**
 * Model/Branch.php
 * Attributs + Getters + Setters UNIQUEMENT
 */
class Branch {

    private int    $id_branch;
    private string $nom;
    private int    $id_repo;
    private int    $id_createur;
    private string $date_creation;
    private bool   $is_default;    // true si c'est la branche main

    public function __construct(
        int    $id_branch     = 0,
        string $nom           = '',
        int    $id_repo       = 0,
        int    $id_createur   = 0,
        string $date_creation = '',
        bool   $is_default    = false
    ) {
        $this->id_branch     = $id_branch;
        $this->nom           = $nom;
        $this->id_repo       = $id_repo;
        $this->id_createur   = $id_createur;
        $this->date_creation = $date_creation;
        $this->is_default    = $is_default;
    }

    public function getIdBranch():    int    { return $this->id_branch;     }
    public function getNom():         string { return $this->nom;           }
    public function getIdRepo():      int    { return $this->id_repo;       }
    public function getIdCreateur():  int    { return $this->id_createur;   }
    public function getDateCreation():string { return $this->date_creation; }
    public function getIsDefault():   bool   { return $this->is_default;    }

    public function setIdBranch(int $id):       void { $this->id_branch     = $id;     }
    public function setNom(string $nom):        void { $this->nom           = $nom;    }
    public function setIdRepo(int $id):         void { $this->id_repo       = $id;     }
    public function setIdCreateur(int $id):     void { $this->id_createur   = $id;     }
    public function setDateCreation(string $d): void { $this->date_creation = $d;      }
    public function setIsDefault(bool $b):      void { $this->is_default    = $b;      }
}
?>
