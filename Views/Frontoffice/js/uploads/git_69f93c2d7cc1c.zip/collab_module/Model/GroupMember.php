<?php
/**
 * Model/GroupMember.php
 * Attributs + Getters + Setters UNIQUEMENT
 */
class GroupMember {

    private int    $id_member;
    private int    $id_group;
    private int    $id_user;
    private string $role;           // 'owner' | 'member'
    private string $date_joined;

    public function __construct(
        int    $id_member   = 0,
        int    $id_group    = 0,
        int    $id_user     = 0,
        string $role        = 'member',
        string $date_joined = ''
    ) {
        $this->id_member   = $id_member;
        $this->id_group    = $id_group;
        $this->id_user     = $id_user;
        $this->role        = $role;
        $this->date_joined = $date_joined;
    }

    public function getIdMember():   int    { return $this->id_member;   }
    public function getIdGroup():    int    { return $this->id_group;    }
    public function getIdUser():     int    { return $this->id_user;     }
    public function getRole():       string { return $this->role;        }
    public function getDateJoined(): string { return $this->date_joined; }

    public function setIdMember(int $id):      void { $this->id_member   = $id;   }
    public function setIdGroup(int $id):       void { $this->id_group    = $id;   }
    public function setIdUser(int $id):        void { $this->id_user     = $id;   }
    public function setRole(string $role):     void { $this->role        = $role; }
    public function setDateJoined(string $d):  void { $this->date_joined = $d;    }
}
?>
