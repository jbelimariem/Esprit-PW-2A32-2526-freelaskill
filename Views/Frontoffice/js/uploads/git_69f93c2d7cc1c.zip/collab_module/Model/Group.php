<?php
/**
 * Model/Group.php
 * Attributs + Getters + Setters UNIQUEMENT
 */
class Group {

    private int     $id_group;
    private string  $nom;
    private string  $description;
    private int     $id_createur;
    private string  $date_creation;
    private string  $visibilite;   // 'public' | 'prive'

    public function __construct(
        int    $id_group      = 0,
        string $nom           = '',
        string $description   = '',
        int    $id_createur   = 0,
        string $date_creation = '',
        string $visibilite    = 'public'
    ) {
        $this->id_group      = $id_group;
        $this->nom           = $nom;
        $this->description   = $description;
        $this->id_createur   = $id_createur;
        $this->date_creation = $date_creation;
        $this->visibilite    = $visibilite;
    }

    public function getIdGroup():      int    { return $this->id_group;      }
    public function getNom():          string { return $this->nom;           }
    public function getDescription():  string { return $this->description;   }
    public function getIdCreateur():   int    { return $this->id_createur;   }
    public function getDateCreation(): string { return $this->date_creation; }
    public function getVisibilite():   string { return $this->visibilite;    }

    public function setIdGroup(int $id):         void { $this->id_group      = $id;         }
    public function setNom(string $nom):         void { $this->nom           = $nom;        }
    public function setDescription(string $d):   void { $this->description   = $d;          }
    public function setIdCreateur(int $id):      void { $this->id_createur   = $id;         }
    public function setDateCreation(string $d):  void { $this->date_creation = $d;          }
    public function setVisibilite(string $v):    void { $this->visibilite    = $v;          }
}
?>
