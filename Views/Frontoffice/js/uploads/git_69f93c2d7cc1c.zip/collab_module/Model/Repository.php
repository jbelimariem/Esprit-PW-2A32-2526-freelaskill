<?php
/**
 * Model/Repository.php
 * Attributs + Getters + Setters UNIQUEMENT
 */
class Repository {

    private int    $id_repo;
    private string $nom;
    private string $description;
    private int    $id_group;
    private int    $id_createur;
    private string $date_creation;
    private string $branche_defaut;  // généralement 'main'

    public function __construct(
        int    $id_repo        = 0,
        string $nom            = '',
        string $description    = '',
        int    $id_group       = 0,
        int    $id_createur    = 0,
        string $date_creation  = '',
        string $branche_defaut = 'main'
    ) {
        $this->id_repo        = $id_repo;
        $this->nom            = $nom;
        $this->description    = $description;
        $this->id_group       = $id_group;
        $this->id_createur    = $id_createur;
        $this->date_creation  = $date_creation;
        $this->branche_defaut = $branche_defaut;
    }

    public function getIdRepo():        int    { return $this->id_repo;        }
    public function getNom():           string { return $this->nom;            }
    public function getDescription():   string { return $this->description;    }
    public function getIdGroup():       int    { return $this->id_group;       }
    public function getIdCreateur():    int    { return $this->id_createur;    }
    public function getDateCreation():  string { return $this->date_creation;  }
    public function getBrancheDefaut(): string { return $this->branche_defaut; }

    public function setIdRepo(int $id):          void { $this->id_repo        = $id;  }
    public function setNom(string $nom):         void { $this->nom            = $nom; }
    public function setDescription(string $d):   void { $this->description    = $d;   }
    public function setIdGroup(int $id):         void { $this->id_group       = $id;  }
    public function setIdCreateur(int $id):      void { $this->id_createur    = $id;  }
    public function setDateCreation(string $d):  void { $this->date_creation  = $d;   }
    public function setBrancheDefaut(string $b): void { $this->branche_defaut = $b;   }
}
?>
