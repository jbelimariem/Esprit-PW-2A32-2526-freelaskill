<?php
/**
 * Model/Commit.php
 * Attributs + Getters + Setters UNIQUEMENT
 */
class Commit {

    private int    $id_commit;
    private string $message;
    private int    $id_branch;
    private int    $id_auteur;
    private string $date_commit;
    private string $contenu;      // le code / texte déposé dans ce commit
    private string $nom_fichier;  // nom du fichier (ex: index.php)
    private string $langage;      // ex: php, js, python, text...

    public function __construct(
        int    $id_commit   = 0,
        string $message     = '',
        int    $id_branch   = 0,
        int    $id_auteur   = 0,
        string $date_commit = '',
        string $contenu     = '',
        string $nom_fichier = '',
        string $langage     = 'text'
    ) {
        $this->id_commit   = $id_commit;
        $this->message     = $message;
        $this->id_branch   = $id_branch;
        $this->id_auteur   = $id_auteur;
        $this->date_commit = $date_commit;
        $this->contenu     = $contenu;
        $this->nom_fichier = $nom_fichier;
        $this->langage     = $langage;
    }

    public function getIdCommit():   int    { return $this->id_commit;   }
    public function getMessage():    string { return $this->message;     }
    public function getIdBranch():   int    { return $this->id_branch;   }
    public function getIdAuteur():   int    { return $this->id_auteur;   }
    public function getDateCommit(): string { return $this->date_commit; }
    public function getContenu():    string { return $this->contenu;     }
    public function getNomFichier(): string { return $this->nom_fichier; }
    public function getLangage():    string { return $this->langage;     }

    public function setIdCommit(int $id):       void { $this->id_commit   = $id;      }
    public function setMessage(string $msg):    void { $this->message     = $msg;     }
    public function setIdBranch(int $id):       void { $this->id_branch   = $id;      }
    public function setIdAuteur(int $id):       void { $this->id_auteur   = $id;      }
    public function setDateCommit(string $d):   void { $this->date_commit = $d;       }
    public function setContenu(string $c):      void { $this->contenu     = $c;       }
    public function setNomFichier(string $nom): void { $this->nom_fichier = $nom;     }
    public function setLangage(string $lang):   void { $this->langage     = $lang;    }
}
?>
