<?php
// Controller/CollabController.php

require_once __DIR__ . '/../Model/Group.php';
require_once __DIR__ . '/../Model/GroupMember.php';
require_once __DIR__ . '/../Model/Repository.php';
require_once __DIR__ . '/../Model/Branch.php';
require_once __DIR__ . '/../Model/Commit.php';

class CollabController {

    private $pdo;

    public function __construct() {
        $this->pdo = config::getConnexion();
    }

    // ─────────────────────────────────────────────────────────────────────
    // Helper : réponse JSON + exit
    // ─────────────────────────────────────────────────────────────────────

    private function jsonResponse(array $data): void {
        if (ob_get_level()) ob_clean();
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }

    // ─────────────────────────────────────────────────────────────────────
    // Helper : vérifier si l'utilisateur est membre d'un groupe
    // ─────────────────────────────────────────────────────────────────────

    private function isMembre(int $id_group, int $id_user): bool {
        $stmt = $this->pdo->prepare("
            SELECT id_member FROM collab_group_members
            WHERE id_group = :g AND id_user = :u
        ");
        $stmt->execute([':g' => $id_group, ':u' => $id_user]);
        return (bool) $stmt->fetch();
    }

    // ─────────────────────────────────────────────────────────────────────
    // Helper : vérifier si l'utilisateur est owner d'un groupe
    // ─────────────────────────────────────────────────────────────────────

    private function isOwner(int $id_group, int $id_user): bool {
        $stmt = $this->pdo->prepare("
            SELECT id_member FROM collab_group_members
            WHERE id_group = :g AND id_user = :u AND role = 'owner'
        ");
        $stmt->execute([':g' => $id_group, ':u' => $id_user]);
        return (bool) $stmt->fetch();
    }

    // ─────────────────────────────────────────────────────────────────────
    // GROUPS — VIEWS
    // ─────────────────────────────────────────────────────────────────────

    // Page liste des groupes
    public function listGroups(): void {
        $id_user = (int) $_SESSION['user_id'];

        // Groupes dont l'utilisateur est membre
        $stmt = $this->pdo->prepare("
            SELECT g.*, gm.role,
                   (SELECT COUNT(*) FROM collab_group_members gm2 WHERE gm2.id_group = g.id_group) AS nb_membres,
                   (SELECT COUNT(*) FROM collab_repositories r WHERE r.id_group = g.id_group) AS nb_repos
            FROM collab_groups g
            JOIN collab_group_members gm ON gm.id_group = g.id_group AND gm.id_user = :u
            ORDER BY g.date_creation DESC
        ");
        $stmt->execute([':u' => $id_user]);
        $mes_groupes = $stmt->fetchAll();

        // Groupes publics auxquels l'utilisateur n'appartient pas
        $stmt = $this->pdo->prepare("
            SELECT g.*,
                   (SELECT COUNT(*) FROM collab_group_members gm2 WHERE gm2.id_group = g.id_group) AS nb_membres,
                   (SELECT COUNT(*) FROM collab_repositories r WHERE r.id_group = g.id_group) AS nb_repos
            FROM collab_groups g
            WHERE g.visibilite = 'public'
              AND g.id_group NOT IN (
                  SELECT id_group FROM collab_group_members WHERE id_user = :u
              )
            ORDER BY g.date_creation DESC
        ");
        $stmt->execute([':u' => $id_user]);
        $groupes_publics = $stmt->fetchAll();

        include __DIR__ . '/../Views/Frontoffice/collab/groups.php';
    }

    // Page détail d'un groupe (liste ses repos)
    public function showGroup(int $id_group): void {
        $id_user = (int) $_SESSION['user_id'];

        $stmt = $this->pdo->prepare("SELECT * FROM collab_groups WHERE id_group = :id");
        $stmt->execute([':id' => $id_group]);
        $groupRow = $stmt->fetch();

        if (!$groupRow) {
            header('Location: index.php?page=collab');
            exit;
        }

        // Accès : groupe public ou membre
        if ($groupRow['visibilite'] === 'prive' && !$this->isMembre($id_group, $id_user)) {
            header('Location: index.php?page=collab');
            exit;
        }

        $group = new Group(
            (int) $groupRow['id_group'],
                  $groupRow['nom'],
                  $groupRow['description'] ?? '',
            (int) $groupRow['id_createur'],
                  $groupRow['date_creation'],
                  $groupRow['visibilite']
        );

        $estMembre = $this->isMembre($id_group, $id_user);
        $estOwner  = $this->isOwner($id_group, $id_user);

        // Membres du groupe
        $stmt = $this->pdo->prepare("
            SELECT gm.*, u.nom AS user_nom, u.prenom AS user_prenom, u.email
            FROM collab_group_members gm
            JOIN users u ON u.id_user = gm.id_user
            WHERE gm.id_group = :g
            ORDER BY gm.role DESC, gm.date_joined ASC
        ");
        $stmt->execute([':g' => $id_group]);
        $membres = $stmt->fetchAll();

        // Dépôts du groupe
        $stmt = $this->pdo->prepare("
            SELECT r.*,
                   (SELECT COUNT(*) FROM collab_branches b WHERE b.id_repo = r.id_repo) AS nb_branches,
                   (SELECT COUNT(*) FROM collab_commits  c
                    JOIN collab_branches b ON b.id_branch = c.id_branch
                    WHERE b.id_repo = r.id_repo) AS nb_commits
            FROM collab_repositories r
            WHERE r.id_group = :g
            ORDER BY r.date_creation DESC
        ");
        $stmt->execute([':g' => $id_group]);
        $repos = $stmt->fetchAll();

        include __DIR__ . '/../Views/Frontoffice/collab/group_detail.php';
    }

    // ─────────────────────────────────────────────────────────────────────
    // GROUPS — ACTIONS
    // ─────────────────────────────────────────────────────────────────────

    public function createGroup(): void {
        $id_user     = (int) $_SESSION['user_id'];
        $nom         = trim($_POST['nom'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $visibilite  = in_array($_POST['visibilite'] ?? '', ['public','prive']) ? $_POST['visibilite'] : 'public';

        if (empty($nom)) $this->jsonResponse(['error' => 'Nom du groupe requis']);

        $nom         = htmlspecialchars($nom, ENT_QUOTES, 'UTF-8');
        $description = htmlspecialchars($description, ENT_QUOTES, 'UTF-8');

        try {
            $stmt = $this->pdo->prepare("
                INSERT INTO collab_groups (nom, description, id_createur, date_creation, visibilite)
                VALUES (:nom, :desc, :createur, NOW(), :vis)
            ");
            $stmt->execute([
                ':nom'      => $nom,
                ':desc'     => $description,
                ':createur' => $id_user,
                ':vis'      => $visibilite,
            ]);
            $id_group = (int) $this->pdo->lastInsertId();

            // Le créateur devient owner
            $stmt = $this->pdo->prepare("
                INSERT INTO collab_group_members (id_group, id_user, role, date_joined)
                VALUES (:g, :u, 'owner', NOW())
            ");
            $stmt->execute([':g' => $id_group, ':u' => $id_user]);

            $this->jsonResponse(['success' => true, 'id_group' => $id_group]);
        } catch (PDOException $e) {
            $this->jsonResponse(['error' => 'PDO: ' . $e->getMessage()]);
        }
    }

    public function joinGroup(): void {
        $id_user  = (int) $_SESSION['user_id'];
        $id_group = (int) ($_POST['id_group'] ?? 0);

        if ($id_group <= 0) $this->jsonResponse(['error' => 'ID groupe invalide']);
        if ($this->isMembre($id_group, $id_user)) $this->jsonResponse(['error' => 'Déjà membre']);

        $stmt = $this->pdo->prepare("SELECT visibilite FROM collab_groups WHERE id_group = :id");
        $stmt->execute([':id' => $id_group]);
        $group = $stmt->fetch();

        if (!$group)                          $this->jsonResponse(['error' => 'Groupe introuvable']);
        if ($group['visibilite'] === 'prive') $this->jsonResponse(['error' => 'Groupe privé']);

        $stmt = $this->pdo->prepare("
            INSERT INTO collab_group_members (id_group, id_user, role, date_joined)
            VALUES (:g, :u, 'member', NOW())
        ");
        $this->jsonResponse(['success' => $stmt->execute([':g' => $id_group, ':u' => $id_user])]);
    }

    public function leaveGroup(): void {
        $id_user  = (int) $_SESSION['user_id'];
        $id_group = (int) ($_POST['id_group'] ?? 0);

        if ($this->isOwner($id_group, $id_user)) $this->jsonResponse(['error' => 'Le propriétaire ne peut pas quitter le groupe']);

        $stmt = $this->pdo->prepare("DELETE FROM collab_group_members WHERE id_group = :g AND id_user = :u");
        $this->jsonResponse(['success' => $stmt->execute([':g' => $id_group, ':u' => $id_user])]);
    }

    public function deleteGroup(): void {
        $id_user  = (int) $_SESSION['user_id'];
        $id_group = (int) ($_POST['id_group'] ?? 0);

        if (!$this->isOwner($id_group, $id_user)) $this->jsonResponse(['error' => 'Non autorisé']);

        // Suppression en cascade (membres, repos, branches, commits)
        $stmt = $this->pdo->prepare("
            DELETE c FROM collab_commits c
            JOIN collab_branches b ON b.id_branch = c.id_branch
            JOIN collab_repositories r ON r.id_repo = b.id_repo
            WHERE r.id_group = :g
        ");
        $stmt->execute([':g' => $id_group]);

        $stmt = $this->pdo->prepare("
            DELETE b FROM collab_branches b
            JOIN collab_repositories r ON r.id_repo = b.id_repo
            WHERE r.id_group = :g
        ");
        $stmt->execute([':g' => $id_group]);

        $stmt = $this->pdo->prepare("DELETE FROM collab_repositories WHERE id_group = :g");
        $stmt->execute([':g' => $id_group]);

        $stmt = $this->pdo->prepare("DELETE FROM collab_group_members WHERE id_group = :g");
        $stmt->execute([':g' => $id_group]);

        $stmt = $this->pdo->prepare("DELETE FROM collab_groups WHERE id_group = :g");
        $ok   = $stmt->execute([':g' => $id_group]);

        $this->jsonResponse(['success' => $ok]);
    }

    // ─────────────────────────────────────────────────────────────────────
    // REPOSITORIES — VIEWS
    // ─────────────────────────────────────────────────────────────────────

    public function showRepo(int $id_repo): void {
        $id_user = (int) $_SESSION['user_id'];

        $stmt = $this->pdo->prepare("SELECT * FROM collab_repositories WHERE id_repo = :id");
        $stmt->execute([':id' => $id_repo]);
        $repoRow = $stmt->fetch();

        if (!$repoRow || !$this->isMembre((int)$repoRow['id_group'], $id_user)) {
            header('Location: index.php?page=collab');
            exit;
        }

        $repo = new Repository(
            (int) $repoRow['id_repo'],
                  $repoRow['nom'],
                  $repoRow['description'] ?? '',
            (int) $repoRow['id_group'],
            (int) $repoRow['id_createur'],
                  $repoRow['date_creation'],
                  $repoRow['branche_defaut']
        );

        // Branches du dépôt
        $stmt = $this->pdo->prepare("
            SELECT b.*,
                   (SELECT COUNT(*) FROM collab_commits c WHERE c.id_branch = b.id_branch) AS nb_commits,
                   (SELECT date_commit FROM collab_commits c WHERE c.id_branch = b.id_branch ORDER BY date_commit DESC LIMIT 1) AS last_commit_date,
                   (SELECT message FROM collab_commits c WHERE c.id_branch = b.id_branch ORDER BY date_commit DESC LIMIT 1) AS last_commit_msg
            FROM collab_branches b
            WHERE b.id_repo = :id
            ORDER BY b.is_default DESC, b.date_creation ASC
        ");
        $stmt->execute([':id' => $id_repo]);
        $branches = $stmt->fetchAll();

        $estOwner = $this->isOwner((int)$repoRow['id_group'], $id_user);

        include __DIR__ . '/../Views/Frontoffice/collab/repo_detail.php';
    }

    // ─────────────────────────────────────────────────────────────────────
    // REPOSITORIES — ACTIONS
    // ─────────────────────────────────────────────────────────────────────

    public function createRepo(): void {
        $id_user     = (int) $_SESSION['user_id'];
        $id_group    = (int) ($_POST['id_group'] ?? 0);
        $nom         = trim($_POST['nom'] ?? '');
        $description = trim($_POST['description'] ?? '');

        if (!$this->isMembre($id_group, $id_user)) $this->jsonResponse(['error' => 'Non autorisé']);
        if (empty($nom)) $this->jsonResponse(['error' => 'Nom du dépôt requis']);

        $nom         = htmlspecialchars($nom, ENT_QUOTES, 'UTF-8');
        $description = htmlspecialchars($description, ENT_QUOTES, 'UTF-8');

        try {
            $stmt = $this->pdo->prepare("
                INSERT INTO collab_repositories (nom, description, id_group, id_createur, date_creation, branche_defaut)
                VALUES (:nom, :desc, :g, :u, NOW(), 'main')
            ");
            $stmt->execute([':nom' => $nom, ':desc' => $description, ':g' => $id_group, ':u' => $id_user]);
            $id_repo = (int) $this->pdo->lastInsertId();

            // Créer la branche main automatiquement
            $stmt = $this->pdo->prepare("
                INSERT INTO collab_branches (nom, id_repo, id_createur, date_creation, is_default)
                VALUES ('main', :r, :u, NOW(), 1)
            ");
            $stmt->execute([':r' => $id_repo, ':u' => $id_user]);

            $this->jsonResponse(['success' => true, 'id_repo' => $id_repo]);
        } catch (PDOException $e) {
            $this->jsonResponse(['error' => 'PDO: ' . $e->getMessage()]);
        }
    }

    public function deleteRepo(): void {
        $id_user = (int) $_SESSION['user_id'];
        $id_repo = (int) ($_POST['id_repo'] ?? 0);

        $stmt = $this->pdo->prepare("SELECT id_group FROM collab_repositories WHERE id_repo = :id");
        $stmt->execute([':id' => $id_repo]);
        $row = $stmt->fetch();

        if (!$row || !$this->isOwner((int)$row['id_group'], $id_user)) $this->jsonResponse(['error' => 'Non autorisé']);

        $stmt = $this->pdo->prepare("
            DELETE c FROM collab_commits c
            JOIN collab_branches b ON b.id_branch = c.id_branch
            WHERE b.id_repo = :r
        ");
        $stmt->execute([':r' => $id_repo]);

        $stmt = $this->pdo->prepare("DELETE FROM collab_branches WHERE id_repo = :r");
        $stmt->execute([':r' => $id_repo]);

        $stmt = $this->pdo->prepare("DELETE FROM collab_repositories WHERE id_repo = :r");
        $ok   = $stmt->execute([':r' => $id_repo]);

        $this->jsonResponse(['success' => $ok]);
    }

    // ─────────────────────────────────────────────────────────────────────
    // BRANCHES — VIEWS
    // ─────────────────────────────────────────────────────────────────────

    public function showBranch(int $id_branch): void {
        $id_user = (int) $_SESSION['user_id'];

        $stmt = $this->pdo->prepare("
            SELECT b.*, r.id_group, r.nom AS repo_nom, r.branche_defaut
            FROM collab_branches b
            JOIN collab_repositories r ON r.id_repo = b.id_repo
            WHERE b.id_branch = :id
        ");
        $stmt->execute([':id' => $id_branch]);
        $branchRow = $stmt->fetch();

        if (!$branchRow || !$this->isMembre((int)$branchRow['id_group'], $id_user)) {
            header('Location: index.php?page=collab');
            exit;
        }

        $branch = new Branch(
            (int) $branchRow['id_branch'],
                  $branchRow['nom'],
            (int) $branchRow['id_repo'],
            (int) $branchRow['id_createur'],
                  $branchRow['date_creation'],
            (bool) $branchRow['is_default']
        );

        // Liste des commits de la branche
        $stmt = $this->pdo->prepare("
            SELECT c.*, u.nom AS auteur_nom, u.prenom AS auteur_prenom
            FROM collab_commits c
            JOIN users u ON u.id_user = c.id_auteur
            WHERE c.id_branch = :id
            ORDER BY c.date_commit DESC
        ");
        $stmt->execute([':id' => $id_branch]);
        $commits = $stmt->fetchAll();

        // Toutes les branches du même dépôt (pour le switcher)
        $stmt = $this->pdo->prepare("SELECT * FROM collab_branches WHERE id_repo = :r ORDER BY is_default DESC, nom ASC");
        $stmt->execute([':r' => $branchRow['id_repo']]);
        $allBranches = $stmt->fetchAll();

        $estOwner = $this->isOwner((int)$branchRow['id_group'], $id_user);

        include __DIR__ . '/../Views/Frontoffice/collab/branch_detail.php';
    }

    // ─────────────────────────────────────────────────────────────────────
    // BRANCHES — ACTIONS
    // ─────────────────────────────────────────────────────────────────────

    public function createBranch(): void {
        $id_user = (int) $_SESSION['user_id'];
        $id_repo = (int) ($_POST['id_repo'] ?? 0);
        $nom     = trim($_POST['nom'] ?? '');

        // Vérifier accès via le repo
        $stmt = $this->pdo->prepare("SELECT id_group FROM collab_repositories WHERE id_repo = :id");
        $stmt->execute([':id' => $id_repo]);
        $row = $stmt->fetch();

        if (!$row || !$this->isMembre((int)$row['id_group'], $id_user)) $this->jsonResponse(['error' => 'Non autorisé']);
        if (empty($nom)) $this->jsonResponse(['error' => 'Nom de branche requis']);

        $nom = htmlspecialchars(preg_replace('/[^a-zA-Z0-9_\-]/', '-', $nom), ENT_QUOTES, 'UTF-8');

        // Vérifier unicité dans le dépôt
        $stmt = $this->pdo->prepare("SELECT id_branch FROM collab_branches WHERE id_repo = :r AND nom = :n");
        $stmt->execute([':r' => $id_repo, ':n' => $nom]);
        if ($stmt->fetch()) $this->jsonResponse(['error' => 'Une branche avec ce nom existe déjà']);

        $stmt = $this->pdo->prepare("
            INSERT INTO collab_branches (nom, id_repo, id_createur, date_creation, is_default)
            VALUES (:nom, :r, :u, NOW(), 0)
        ");
        $ok = $stmt->execute([':nom' => $nom, ':r' => $id_repo, ':u' => $id_user]);
        $this->jsonResponse(['success' => $ok, 'id_branch' => (int) $this->pdo->lastInsertId()]);
    }

    public function deleteBranch(): void {
        $id_user   = (int) $_SESSION['user_id'];
        $id_branch = (int) ($_POST['id_branch'] ?? 0);

        $stmt = $this->pdo->prepare("
            SELECT b.is_default, r.id_group
            FROM collab_branches b
            JOIN collab_repositories r ON r.id_repo = b.id_repo
            WHERE b.id_branch = :id
        ");
        $stmt->execute([':id' => $id_branch]);
        $row = $stmt->fetch();

        if (!$row)                                          $this->jsonResponse(['error' => 'Branche introuvable']);
        if (!$this->isOwner((int)$row['id_group'], $id_user)) $this->jsonResponse(['error' => 'Non autorisé']);
        if ($row['is_default'])                             $this->jsonResponse(['error' => 'Impossible de supprimer la branche principale']);

        $stmt = $this->pdo->prepare("DELETE FROM collab_commits  WHERE id_branch = :id");
        $stmt->execute([':id' => $id_branch]);

        $stmt = $this->pdo->prepare("DELETE FROM collab_branches WHERE id_branch = :id");
        $ok   = $stmt->execute([':id' => $id_branch]);

        $this->jsonResponse(['success' => $ok]);
    }

    // ─────────────────────────────────────────────────────────────────────
    // COMMITS — VIEWS
    // ─────────────────────────────────────────────────────────────────────

    public function showCommit(int $id_commit): void {
        $id_user = (int) $_SESSION['user_id'];

        $stmt = $this->pdo->prepare("
            SELECT c.*, b.id_repo, b.nom AS branch_nom, r.id_group, r.nom AS repo_nom,
                   u.nom AS auteur_nom, u.prenom AS auteur_prenom
            FROM collab_commits c
            JOIN collab_branches b ON b.id_branch = c.id_branch
            JOIN collab_repositories r ON r.id_repo = b.id_repo
            JOIN users u ON u.id_user = c.id_auteur
            WHERE c.id_commit = :id
        ");
        $stmt->execute([':id' => $id_commit]);
        $row = $stmt->fetch();

        if (!$row || !$this->isMembre((int)$row['id_group'], $id_user)) {
            header('Location: index.php?page=collab');
            exit;
        }

        $commit = new Commit(
            (int) $row['id_commit'],
                  $row['message'],
            (int) $row['id_branch'],
            (int) $row['id_auteur'],
                  $row['date_commit'],
                  $row['contenu'],
                  $row['nom_fichier'],
                  $row['langage']
        );

        include __DIR__ . '/../Views/Frontoffice/collab/commit_detail.php';
    }

    // ─────────────────────────────────────────────────────────────────────
    // COMMITS — ACTIONS
    // ─────────────────────────────────────────────────────────────────────

    public function createCommit(): void {
        $id_user    = (int) $_SESSION['user_id'];
        $id_branch  = (int) ($_POST['id_branch'] ?? 0);
        $message    = trim($_POST['message'] ?? '');
        $contenu    = $_POST['contenu'] ?? '';
        $nom_fichier = trim($_POST['nom_fichier'] ?? 'fichier.txt');
        $langage    = trim($_POST['langage'] ?? 'text');

        // Vérifier accès
        $stmt = $this->pdo->prepare("
            SELECT b.id_repo, r.id_group
            FROM collab_branches b
            JOIN collab_repositories r ON r.id_repo = b.id_repo
            WHERE b.id_branch = :id
        ");
        $stmt->execute([':id' => $id_branch]);
        $row = $stmt->fetch();

        if (!$row || !$this->isMembre((int)$row['id_group'], $id_user)) $this->jsonResponse(['error' => 'Non autorisé']);
        if (empty($message)) $this->jsonResponse(['error' => 'Message de commit requis']);
        if (empty($contenu)) $this->jsonResponse(['error' => 'Contenu vide']);

        $message     = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');
        $nom_fichier = htmlspecialchars($nom_fichier, ENT_QUOTES, 'UTF-8');
        $langage     = htmlspecialchars($langage, ENT_QUOTES, 'UTF-8');
        // contenu non échappé pour préserver le code

        $stmt = $this->pdo->prepare("
            INSERT INTO collab_commits (message, id_branch, id_auteur, date_commit, contenu, nom_fichier, langage)
            VALUES (:msg, :branch, :auteur, NOW(), :contenu, :fichier, :lang)
        ");
        $ok = $stmt->execute([
            ':msg'     => $message,
            ':branch'  => $id_branch,
            ':auteur'  => $id_user,
            ':contenu' => $contenu,
            ':fichier' => $nom_fichier,
            ':lang'    => $langage,
        ]);

        $this->jsonResponse(['success' => $ok, 'id_commit' => (int) $this->pdo->lastInsertId()]);
    }

    public function deleteCommit(): void {
        $id_user   = (int) $_SESSION['user_id'];
        $id_commit = (int) ($_POST['id_commit'] ?? 0);

        $stmt = $this->pdo->prepare("
            SELECT c.id_auteur, r.id_group
            FROM collab_commits c
            JOIN collab_branches b ON b.id_branch = c.id_branch
            JOIN collab_repositories r ON r.id_repo = b.id_repo
            WHERE c.id_commit = :id
        ");
        $stmt->execute([':id' => $id_commit]);
        $row = $stmt->fetch();

        if (!$row) $this->jsonResponse(['error' => 'Commit introuvable']);

        // Seul l'auteur ou un owner peut supprimer
        $canDelete = ($row['id_auteur'] == $id_user) || $this->isOwner((int)$row['id_group'], $id_user);
        if (!$canDelete) $this->jsonResponse(['error' => 'Non autorisé']);

        $stmt = $this->pdo->prepare("DELETE FROM collab_commits WHERE id_commit = :id");
        $ok   = $stmt->execute([':id' => $id_commit]);

        $this->jsonResponse(['success' => $ok]);
    }
}
?>
