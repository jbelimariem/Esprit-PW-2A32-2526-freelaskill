<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Commit #<?= $commit->getIdCommit() ?> — FreelaSkill</title>
<style>
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'Segoe UI', sans-serif; background: #f5f6fa; color: #1a1a2e; }
.page-wrap { max-width: 1000px; margin: 0 auto; padding: 30px 20px; }
.breadcrumb { font-size: 13px; color: #9ca3af; margin-bottom: 20px; }
.breadcrumb a { color: #4361ee; text-decoration: none; }
.breadcrumb a:hover { text-decoration: underline; }

/* Commit header */
.commit-header { background: #fff; border-radius: 14px; padding: 22px 26px; margin-bottom: 20px; border: 1.5px solid #e9ecef; }
.commit-header h1 { font-size: 18px; font-weight: 700; margin-bottom: 10px; }
.commit-meta-row { display: flex; gap: 20px; flex-wrap: wrap; }
.meta-item { font-size: 13px; color: #6c757d; display: flex; align-items: center; gap: 5px; }
.meta-item strong { color: #1a1a2e; }
.commit-hash { font-family: 'Courier New', monospace; font-size: 12px; background: #f3f4f6; padding: 2px 8px; border-radius: 5px; color: #4361ee; }

/* File viewer */
.file-viewer { background: #1e1e3f; border-radius: 14px; overflow: hidden; margin-bottom: 20px; }
.file-viewer-header { background: #2d2d5e; padding: 12px 18px; display: flex; align-items: center; justify-content: space-between; }
.file-name { color: #e2e8f0; font-size: 14px; font-weight: 600; display: flex; align-items: center; gap: 8px; }
.lang-badge { font-size: 11px; padding: 2px 8px; border-radius: 20px; background: #4361ee; color: #fff; }
.btn-copy { background: #3d3d70; color: #e2e8f0; border: none; border-radius: 6px; padding: 5px 12px; font-size: 12px; cursor: pointer; }
.btn-copy:hover { background: #4a4a88; }
.code-block { padding: 20px; overflow-x: auto; }
.code-block pre { font-family: 'Courier New', monospace; font-size: 13px; line-height: 1.7;
                  color: #e2e8f0; white-space: pre-wrap; word-break: break-word; }
.line-nums { color: #4a4a88; user-select: none; margin-right: 16px; }

/* Actions */
.actions-row { display: flex; gap: 10px; }
.btn { display: inline-flex; align-items: center; gap: 6px; padding: 9px 18px; border-radius: 8px;
       border: none; cursor: pointer; font-size: 14px; font-weight: 500; text-decoration: none; transition: .15s; }
.btn-outline { background: #fff; color: #4361ee; border: 1.5px solid #4361ee; }
.btn-outline:hover { background: #eef1fd; }
.btn-danger  { background: #fff; color: #e63946; border: 1.5px solid #e63946; }
.btn-danger:hover  { background: #fdecea; }
</style>
</head>
<body>
<div class="page-wrap">

    <div class="breadcrumb">
        <a href="index.php?page=collab">Groupes</a> /
        <a href="index.php?page=collab&action=group&id=<?= $row['id_group'] ?>">Groupe</a> /
        <a href="index.php?page=collab&action=repo&id=<?= $row['id_repo'] ?>"><?= htmlspecialchars($row['repo_nom']) ?></a> /
        <a href="index.php?page=collab&action=branch&id=<?= $commit->getIdBranch() ?>"><?= htmlspecialchars($row['branch_nom']) ?></a> /
        Commit #<?= $commit->getIdCommit() ?>
    </div>

    <!-- Commit header -->
    <div class="commit-header">
        <h1>✅ <?= htmlspecialchars($commit->getMessage()) ?></h1>
        <div class="commit-meta-row">
            <div class="meta-item">👤 <strong><?= htmlspecialchars(trim(($row['auteur_prenom'] ?? '') . ' ' . ($row['auteur_nom'] ?? ''))) ?></strong></div>
            <div class="meta-item">📅 <strong><?= date('d/m/Y à H:i', strtotime($commit->getDateCommit())) ?></strong></div>
            <div class="meta-item">🌿 <strong><?= htmlspecialchars($row['branch_nom']) ?></strong></div>
            <div class="meta-item"><span class="commit-hash">#<?= $commit->getIdCommit() ?></span></div>
        </div>
    </div>

    <!-- File viewer -->
    <div class="file-viewer">
        <div class="file-viewer-header">
            <div class="file-name">
                📄 <?= htmlspecialchars($commit->getNomFichier()) ?>
                <span class="lang-badge"><?= htmlspecialchars($commit->getLangage()) ?></span>
            </div>
            <button class="btn-copy" onclick="copyCode()">📋 Copier</button>
        </div>
        <div class="code-block">
            <pre id="code-content"><?php
$lines = explode("\n", $commit->getContenu());
foreach ($lines as $i => $line) {
    $num = str_pad($i + 1, 4, ' ', STR_PAD_LEFT);
    echo '<span class="line-nums">' . htmlspecialchars($num) . '</span>' . htmlspecialchars($line) . "\n";
}
?></pre>
        </div>
    </div>

    <!-- Actions -->
    <div class="actions-row">
        <a href="index.php?page=collab&action=branch&id=<?= $commit->getIdBranch() ?>" class="btn btn-outline">← Retour à la branche</a>
        <button class="btn btn-danger" onclick="deleteCommit(<?= $commit->getIdCommit() ?>, <?= $commit->getIdBranch() ?>)">Supprimer ce commit</button>
    </div>

</div>
<script>
function copyCode() {
    const text = <?= json_encode($commit->getContenu()) ?>;
    navigator.clipboard.writeText(text).then(() => {
        const btn = document.querySelector('.btn-copy');
        btn.textContent = '✅ Copié !';
        setTimeout(() => btn.textContent = '📋 Copier', 2000);
    });
}

function deleteCommit(id, branchId) {
    if (!confirm('Supprimer ce commit définitivement ?')) return;
    fetch('index.php?page=collab&action=delete-commit', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'id_commit=' + id
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) location.href = 'index.php?page=collab&action=branch&id=' + branchId;
        else alert(data.error);
    });
}
</script>
</body>
</html>
