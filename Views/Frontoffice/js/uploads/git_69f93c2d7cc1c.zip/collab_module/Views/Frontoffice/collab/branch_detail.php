<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>🌿 <?= htmlspecialchars($branch->getNom()) ?> — FreelaSkill</title>
<style>
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'Segoe UI', sans-serif; background: #f5f6fa; color: #1a1a2e; }
.page-wrap { max-width: 1050px; margin: 0 auto; padding: 30px 20px; }
.breadcrumb { font-size: 13px; color: #9ca3af; margin-bottom: 20px; }
.breadcrumb a { color: #4361ee; text-decoration: none; }
.breadcrumb a:hover { text-decoration: underline; }

/* Branch header */
.branch-header { background: #fff; border-radius: 14px; padding: 20px 24px; margin-bottom: 24px;
                 border: 1.5px solid #e9ecef; display: flex; align-items: center; justify-content: space-between; gap: 16px; }
.branch-header-left { display: flex; align-items: center; gap: 12px; }
.branch-header-left h1 { font-size: 18px; font-weight: 700; }
.branch-switcher { border: 1.5px solid #e5e7eb; border-radius: 8px; padding: 6px 10px;
                   font-size: 13px; outline: none; cursor: pointer; background: #fff; }
.badge-default { font-size: 11px; padding: 2px 10px; border-radius: 20px; background: #dbeafe; color: #1e40af; }

/* Buttons */
.btn { display: inline-flex; align-items: center; gap: 6px; padding: 9px 18px; border-radius: 8px;
       border: none; cursor: pointer; font-size: 14px; font-weight: 500; text-decoration: none; transition: .15s; }
.btn-primary { background: #4361ee; color: #fff; }
.btn-primary:hover { background: #3451d1; }
.btn-outline { background: #fff; color: #4361ee; border: 1.5px solid #4361ee; }
.btn-outline:hover { background: #eef1fd; }
.btn-danger  { background: #fff; color: #e63946; border: 1.5px solid #e63946; }
.btn-danger:hover  { background: #fdecea; }
.btn-sm { padding: 5px 12px; font-size: 13px; }
.btn-success { background: #10b981; color: #fff; border: none; }
.btn-success:hover { background: #059669; }

/* Editor panel */
.editor-panel { background: #fff; border-radius: 14px; border: 1.5px solid #e9ecef; margin-bottom: 24px; overflow: hidden; }
.editor-panel-header { background: #1e1e3f; padding: 12px 18px; display: flex; align-items: center;
                        justify-content: space-between; gap: 12px; }
.editor-panel-header h3 { color: #fff; font-size: 14px; font-weight: 600; }
.editor-toolbar { display: flex; align-items: center; gap: 10px; }
.editor-input { font-size: 13px; padding: 5px 10px; border-radius: 6px; border: none; background: #2d2d5e; color: #fff;
                outline: none; font-family: inherit; }
.editor-input::placeholder { color: #8b8bc4; }
textarea.code-editor {
    width: 100%; min-height: 240px; padding: 16px 18px;
    font-family: 'Courier New', monospace; font-size: 13px; line-height: 1.6;
    background: #1a1a3e; color: #e2e8f0; border: none; resize: vertical; outline: none;
    tab-size: 4;
}
.editor-footer { padding: 14px 18px; background: #fff; border-top: 1.5px solid #f3f4f6;
                 display: flex; align-items: center; gap: 10px; }
.editor-footer input { flex: 1; padding: 9px 12px; border: 1.5px solid #e5e7eb; border-radius: 8px;
                       font-size: 14px; outline: none; transition: .15s; font-family: inherit; }
.editor-footer input:focus { border-color: #4361ee; }

/* Commits list */
.section-title { font-size: 15px; font-weight: 600; margin-bottom: 14px; }
.commit-list { display: flex; flex-direction: column; gap: 0; border: 1.5px solid #e9ecef; border-radius: 12px; overflow: hidden; background: #fff; }
.commit-item { padding: 14px 20px; border-bottom: 1px solid #f3f4f6; display: flex; align-items: center; justify-content: space-between; gap: 12px; transition: .1s; }
.commit-item:last-child { border-bottom: none; }
.commit-item:hover { background: #f9fafb; }
.commit-left { flex: 1; min-width: 0; }
.commit-msg  { font-size: 14px; font-weight: 500; color: #1a1a2e; }
.commit-meta { font-size: 12px; color: #9ca3af; margin-top: 3px; }
.commit-hash { font-family: 'Courier New', monospace; font-size: 11px; color: #6c757d; background: #f3f4f6;
               padding: 1px 7px; border-radius: 4px; }
.commit-right { display: flex; gap: 8px; flex-shrink: 0; }

/* Empty state */
.empty-state { text-align: center; padding: 40px; color: #9ca3af; background: #fff;
               border-radius: 12px; border: 1.5px solid #e9ecef; }
.empty-state .icon { font-size: 36px; margin-bottom: 8px; }

/* Alert */
.alert { padding: 10px 14px; border-radius: 8px; font-size: 13px; margin-bottom: 12px; display: none; }
.alert-error   { background: #fee2e2; color: #991b1b; }
.alert-success { background: #d1fae5; color: #065f46; }
</style>
</head>
<body>
<div class="page-wrap">

    <div class="breadcrumb">
        <a href="index.php?page=collab">Groupes</a> /
        <a href="index.php?page=collab&action=group&id=<?= $branchRow['id_group'] ?>">Groupe</a> /
        <a href="index.php?page=collab&action=repo&id=<?= $branch->getIdRepo() ?>"><?= htmlspecialchars($branchRow['repo_nom']) ?></a> /
        <?= htmlspecialchars($branch->getNom()) ?>
    </div>

    <!-- Branch header -->
    <div class="branch-header">
        <div class="branch-header-left">
            <span style="font-size:20px;">🌿</span>
            <h1><?= htmlspecialchars($branch->getNom()) ?></h1>
            <?php if ($branch->getIsDefault()): ?>
            <span class="badge-default">principale</span>
            <?php endif; ?>
            <!-- Branch switcher -->
            <select class="branch-switcher" onchange="location.href='index.php?page=collab&action=branch&id='+this.value">
                <?php foreach ($allBranches as $b): ?>
                <option value="<?= $b['id_branch'] ?>" <?= $b['id_branch'] == $branch->getIdBranch() ? 'selected' : '' ?>>
                    🌿 <?= htmlspecialchars($b['nom']) ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div>
            <?= count($commits) ?> commit<?= count($commits) > 1 ? 's' : '' ?>
        </div>
    </div>

    <!-- Éditeur de code -->
    <div class="alert alert-error"   id="commit-error"></div>
    <div class="alert alert-success" id="commit-success"></div>

    <div class="editor-panel">
        <div class="editor-panel-header">
            <h3>✏️ Nouveau commit</h3>
            <div class="editor-toolbar">
                <input class="editor-input" type="text" id="nom-fichier" placeholder="nom_fichier.php" value="fichier.php" style="width:160px;">
                <select class="editor-input" id="langage">
                    <option value="php">PHP</option>
                    <option value="js">JavaScript</option>
                    <option value="python">Python</option>
                    <option value="html">HTML</option>
                    <option value="css">CSS</option>
                    <option value="sql">SQL</option>
                    <option value="java">Java</option>
                    <option value="c">C/C++</option>
                    <option value="text">Texte</option>
                </select>
            </div>
        </div>
        <textarea class="code-editor" id="code-contenu" placeholder="// Collez ou écrivez votre code ici..."></textarea>
        <div class="editor-footer">
            <input type="text" id="commit-message" placeholder="Message de commit (ex: Ajout de la page login)">
            <button class="btn btn-success" onclick="submitCommit()">✅ Valider le commit</button>
        </div>
    </div>

    <!-- Liste des commits -->
    <div class="section-title">📋 Historique des commits</div>

    <?php if (empty($commits)): ?>
    <div class="empty-state">
        <div class="icon">📭</div>
        <p>Aucun commit sur cette branche.</p>
    </div>
    <?php else: ?>
    <div class="commit-list">
        <?php foreach ($commits as $c): ?>
        <div class="commit-item">
            <div class="commit-left">
                <div class="commit-msg">
                    <?= htmlspecialchars($c['message']) ?>
                    <span class="commit-hash">#<?= $c['id_commit'] ?></span>
                </div>
                <div class="commit-meta">
                    par <strong><?= htmlspecialchars(trim(($c['auteur_prenom'] ?? '') . ' ' . ($c['auteur_nom'] ?? ''))) ?></strong>
                    · <?= date('d/m/Y à H:i', strtotime($c['date_commit'])) ?>
                    · 📄 <?= htmlspecialchars($c['nom_fichier']) ?>
                    · <em><?= htmlspecialchars($c['langage']) ?></em>
                </div>
            </div>
            <div class="commit-right">
                <a href="index.php?page=collab&action=commit&id=<?= $c['id_commit'] ?>" class="btn btn-outline btn-sm">Voir</a>
                <button class="btn btn-danger btn-sm" onclick="deleteCommit(<?= $c['id_commit'] ?>)">Supprimer</button>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

</div>

<script>
const BRANCH_ID = <?= $branch->getIdBranch() ?>;

function submitCommit() {
    const message    = document.getElementById('commit-message').value.trim();
    const contenu    = document.getElementById('code-contenu').value;
    const nomFichier = document.getElementById('nom-fichier').value.trim();
    const langage    = document.getElementById('langage').value;
    const err = document.getElementById('commit-error');
    const ok  = document.getElementById('commit-success');
    err.style.display = 'none';
    ok.style.display  = 'none';

    if (!message) { err.textContent = 'Le message de commit est requis.'; err.style.display = 'block'; return; }
    if (!contenu) { err.textContent = 'Le contenu est vide.'; err.style.display = 'block'; return; }

    const body = new URLSearchParams({
        id_branch:   BRANCH_ID,
        message:     message,
        contenu:     contenu,
        nom_fichier: nomFichier,
        langage:     langage
    });

    fetch('index.php?page=collab&action=create-commit', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: body.toString()
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            ok.textContent = 'Commit créé avec succès !';
            ok.style.display = 'block';
            document.getElementById('commit-message').value = '';
            document.getElementById('code-contenu').value   = '';
            setTimeout(() => location.reload(), 800);
        } else {
            err.textContent = data.error || 'Erreur.';
            err.style.display = 'block';
        }
    });
}

function deleteCommit(id) {
    if (!confirm('Supprimer ce commit ?')) return;
    fetch('index.php?page=collab&action=delete-commit', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'id_commit=' + id
    })
    .then(r => r.json())
    .then(data => { if (data.success) location.reload(); else alert(data.error); });
}

// Tab key dans l'éditeur
document.getElementById('code-contenu').addEventListener('keydown', function(e) {
    if (e.key === 'Tab') {
        e.preventDefault();
        const s = this.selectionStart, end = this.selectionEnd;
        this.value = this.value.substring(0, s) + '    ' + this.value.substring(end);
        this.selectionStart = this.selectionEnd = s + 4;
    }
});
</script>
</body>
</html>
