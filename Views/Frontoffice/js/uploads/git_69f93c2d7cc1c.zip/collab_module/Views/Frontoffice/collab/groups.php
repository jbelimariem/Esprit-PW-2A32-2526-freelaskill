<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Collaboration — FreelaSkill</title>
<style>
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'Segoe UI', sans-serif; background: #f5f6fa; color: #1a1a2e; }
.page-wrap { max-width: 1100px; margin: 0 auto; padding: 30px 20px; }

/* Header */
.page-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 32px; }
.page-header h1 { font-size: 22px; font-weight: 700; }
.page-header h1 span { color: #4361ee; }
.btn { display: inline-flex; align-items: center; gap: 6px; padding: 9px 18px; border-radius: 8px;
       border: none; cursor: pointer; font-size: 14px; font-weight: 500; text-decoration: none; transition: .15s; }
.btn-primary { background: #4361ee; color: #fff; }
.btn-primary:hover { background: #3451d1; }
.btn-outline { background: #fff; color: #4361ee; border: 1.5px solid #4361ee; }
.btn-outline:hover { background: #eef1fd; }
.btn-danger  { background: #fff; color: #e63946; border: 1.5px solid #e63946; }
.btn-danger:hover  { background: #fdecea; }
.btn-sm { padding: 5px 12px; font-size: 13px; }

/* Tabs */
.tabs { display: flex; gap: 4px; background: #e9ecef; border-radius: 10px; padding: 4px; margin-bottom: 28px; width: fit-content; }
.tab  { padding: 7px 20px; border-radius: 7px; font-size: 14px; font-weight: 500; cursor: pointer;
        background: transparent; border: none; color: #6c757d; transition: .15s; }
.tab.active { background: #fff; color: #4361ee; box-shadow: 0 1px 4px rgba(0,0,0,.1); }

/* Groups grid */
.groups-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 18px; }
.group-card  { background: #fff; border-radius: 12px; padding: 20px 22px; border: 1.5px solid #e9ecef;
               transition: .15s; text-decoration: none; color: inherit; display: block; }
.group-card:hover { border-color: #4361ee; box-shadow: 0 4px 16px rgba(67,97,238,.1); }
.group-card-head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px; }
.group-name  { font-size: 16px; font-weight: 600; }
.badge-vis   { font-size: 11px; padding: 2px 10px; border-radius: 20px; font-weight: 500; }
.badge-public { background: #d1fae5; color: #065f46; }
.badge-prive  { background: #fee2e2; color: #991b1b; }
.badge-owner  { background: #ede9fe; color: #5b21b6; }
.badge-member { background: #dbeafe; color: #1e40af; }
.group-desc  { font-size: 13px; color: #6c757d; margin-bottom: 14px; line-height: 1.5;
               min-height: 38px; }
.group-meta  { display: flex; gap: 16px; font-size: 12px; color: #9ca3af; border-top: 1px solid #f3f4f6; padding-top: 12px; }
.group-meta span { display: flex; align-items: center; gap: 4px; }
.group-actions { display: flex; gap: 8px; margin-top: 12px; }

/* Empty state */
.empty-state { text-align: center; padding: 60px 20px; color: #9ca3af; }
.empty-state .icon { font-size: 48px; margin-bottom: 12px; }
.empty-state p { font-size: 15px; }

/* Modal */
.modal-backdrop { display: none; position: fixed; inset: 0; background: rgba(0,0,0,.45); z-index: 100; align-items: center; justify-content: center; }
.modal-backdrop.open { display: flex; }
.modal { background: #fff; border-radius: 14px; padding: 28px; width: 460px; max-width: 95vw; }
.modal h2 { font-size: 18px; font-weight: 700; margin-bottom: 20px; }
.form-group { margin-bottom: 14px; }
.form-group label { display: block; font-size: 13px; font-weight: 500; margin-bottom: 5px; color: #374151; }
.form-group input, .form-group textarea, .form-group select {
    width: 100%; padding: 9px 12px; border: 1.5px solid #e5e7eb; border-radius: 8px;
    font-size: 14px; outline: none; transition: .15s; font-family: inherit; }
.form-group input:focus, .form-group textarea:focus, .form-group select:focus { border-color: #4361ee; }
.form-group textarea { resize: vertical; min-height: 70px; }
.modal-footer { display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px; }
.alert { padding: 10px 14px; border-radius: 8px; font-size: 13px; margin-bottom: 12px; display: none; }
.alert-error { background: #fee2e2; color: #991b1b; }
</style>
</head>
<body>
<div class="page-wrap">

    <!-- Header -->
    <div class="page-header">
        <h1>⚡ Collaboration <span>FreelaSkill</span></h1>
        <button class="btn btn-primary" onclick="document.getElementById('modal-create').classList.add('open')">
            + Nouveau groupe
        </button>
    </div>

    <!-- Tabs -->
    <div class="tabs">
        <button class="tab active" onclick="switchTab('mes-groupes', this)">Mes groupes</button>
        <button class="tab"       onclick="switchTab('decouvrir', this)">Découvrir</button>
    </div>

    <!-- MES GROUPES -->
    <div id="mes-groupes">
        <?php if (empty($mes_groupes)): ?>
            <div class="empty-state">
                <div class="icon">📂</div>
                <p>Vous n'êtes dans aucun groupe pour l'instant.</p>
            </div>
        <?php else: ?>
        <div class="groups-grid">
            <?php foreach ($mes_groupes as $g): ?>
            <div class="group-card">
                <div class="group-card-head">
                    <div class="group-name"><?= htmlspecialchars($g['nom']) ?></div>
                    <div style="display:flex;gap:6px;">
                        <span class="badge-vis badge-<?= $g['visibilite'] ?>"><?= $g['visibilite'] ?></span>
                        <span class="badge-vis badge-<?= $g['role'] ?>"><?= $g['role'] ?></span>
                    </div>
                </div>
                <div class="group-desc"><?= htmlspecialchars($g['description'] ?: 'Aucune description.') ?></div>
                <div class="group-meta">
                    <span>👥 <?= $g['nb_membres'] ?> membre<?= $g['nb_membres'] > 1 ? 's' : '' ?></span>
                    <span>📁 <?= $g['nb_repos'] ?> dépôt<?= $g['nb_repos'] > 1 ? 's' : '' ?></span>
                </div>
                <div class="group-actions">
                    <a href="index.php?page=collab&action=group&id=<?= $g['id_group'] ?>" class="btn btn-primary btn-sm">Ouvrir</a>
                    <?php if ($g['role'] !== 'owner'): ?>
                    <button class="btn btn-danger btn-sm" onclick="leaveGroup(<?= $g['id_group'] ?>)">Quitter</button>
                    <?php else: ?>
                    <button class="btn btn-danger btn-sm" onclick="deleteGroup(<?= $g['id_group'] ?>)">Supprimer</button>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>

    <!-- DECOUVRIR -->
    <div id="decouvrir" style="display:none;">
        <?php if (empty($groupes_publics)): ?>
            <div class="empty-state">
                <div class="icon">🔍</div>
                <p>Aucun groupe public disponible.</p>
            </div>
        <?php else: ?>
        <div class="groups-grid">
            <?php foreach ($groupes_publics as $g): ?>
            <div class="group-card">
                <div class="group-card-head">
                    <div class="group-name"><?= htmlspecialchars($g['nom']) ?></div>
                    <span class="badge-vis badge-public">public</span>
                </div>
                <div class="group-desc"><?= htmlspecialchars($g['description'] ?: 'Aucune description.') ?></div>
                <div class="group-meta">
                    <span>👥 <?= $g['nb_membres'] ?> membre<?= $g['nb_membres'] > 1 ? 's' : '' ?></span>
                    <span>📁 <?= $g['nb_repos'] ?> dépôt<?= $g['nb_repos'] > 1 ? 's' : '' ?></span>
                </div>
                <div class="group-actions">
                    <button class="btn btn-primary btn-sm" onclick="joinGroup(<?= $g['id_group'] ?>)">Rejoindre</button>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>

</div>

<!-- Modal : Créer un groupe -->
<div class="modal-backdrop" id="modal-create">
    <div class="modal">
        <h2>Créer un groupe</h2>
        <div class="alert alert-error" id="create-error"></div>
        <div class="form-group">
            <label>Nom du groupe *</label>
            <input type="text" id="create-nom" placeholder="Ex: Team Frontend" maxlength="100">
        </div>
        <div class="form-group">
            <label>Description</label>
            <textarea id="create-desc" placeholder="Décrivez le but du groupe..."></textarea>
        </div>
        <div class="form-group">
            <label>Visibilité</label>
            <select id="create-vis">
                <option value="public">Public (tout le monde peut rejoindre)</option>
                <option value="prive">Privé (sur invitation)</option>
            </select>
        </div>
        <div class="modal-footer">
            <button class="btn btn-outline" onclick="document.getElementById('modal-create').classList.remove('open')">Annuler</button>
            <button class="btn btn-primary" onclick="submitCreateGroup()">Créer le groupe</button>
        </div>
    </div>
</div>

<script>
function switchTab(id, btn) {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('mes-groupes').style.display = id === 'mes-groupes' ? '' : 'none';
    document.getElementById('decouvrir').style.display   = id === 'decouvrir'   ? '' : 'none';
}

function submitCreateGroup() {
    const nom  = document.getElementById('create-nom').value.trim();
    const desc = document.getElementById('create-desc').value.trim();
    const vis  = document.getElementById('create-vis').value;
    const err  = document.getElementById('create-error');
    err.style.display = 'none';

    if (!nom) { err.textContent = 'Le nom est requis.'; err.style.display = 'block'; return; }

    fetch('index.php?page=collab&action=create-group', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: `nom=${encodeURIComponent(nom)}&description=${encodeURIComponent(desc)}&visibilite=${vis}`
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) location.href = 'index.php?page=collab&action=group&id=' + data.id_group;
        else { err.textContent = data.error || 'Erreur.'; err.style.display = 'block'; }
    });
}

function joinGroup(id) {
    if (!confirm('Rejoindre ce groupe ?')) return;
    fetch('index.php?page=collab&action=join-group', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'id_group=' + id
    })
    .then(r => r.json())
    .then(data => { if (data.success) location.reload(); else alert(data.error); });
}

function leaveGroup(id) {
    if (!confirm('Quitter ce groupe ?')) return;
    fetch('index.php?page=collab&action=leave-group', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'id_group=' + id
    })
    .then(r => r.json())
    .then(data => { if (data.success) location.reload(); else alert(data.error); });
}

function deleteGroup(id) {
    if (!confirm('Supprimer définitivement ce groupe et tout son contenu ?')) return;
    fetch('index.php?page=collab&action=delete-group', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'id_group=' + id
    })
    .then(r => r.json())
    .then(data => { if (data.success) location.reload(); else alert(data.error); });
}
</script>
</body>
</html>
