<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title><?= htmlspecialchars($group->getNom()) ?> — FreelaSkill</title>
<style>
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'Segoe UI', sans-serif; background: #f5f6fa; color: #1a1a2e; }
.page-wrap { max-width: 1100px; margin: 0 auto; padding: 30px 20px; }
.breadcrumb { font-size: 13px; color: #9ca3af; margin-bottom: 20px; }
.breadcrumb a { color: #4361ee; text-decoration: none; }
.breadcrumb a:hover { text-decoration: underline; }

/* Header groupe */
.group-header { background: #fff; border-radius: 14px; padding: 24px 28px; margin-bottom: 24px;
                border: 1.5px solid #e9ecef; display: flex; align-items: flex-start; justify-content: space-between; gap: 20px; }
.group-header-left h1 { font-size: 22px; font-weight: 700; margin-bottom: 4px; }
.group-header-left p  { font-size: 14px; color: #6c757d; line-height: 1.5; }
.group-meta-row { display: flex; gap: 16px; margin-top: 12px; }
.meta-chip { font-size: 12px; padding: 3px 12px; border-radius: 20px; font-weight: 500; }
.chip-public  { background: #d1fae5; color: #065f46; }
.chip-prive   { background: #fee2e2; color: #991b1b; }
.group-header-actions { display: flex; gap: 8px; flex-shrink: 0; }

/* Buttons */
.btn { display: inline-flex; align-items: center; gap: 6px; padding: 9px 18px; border-radius: 8px;
       border: none; cursor: pointer; font-size: 14px; font-weight: 500; text-decoration: none; transition: .15s; }
.btn-primary { background: #4361ee; color: #fff; }
.btn-primary:hover { background: #3451d1; }
.btn-outline { background: #fff; color: #4361ee; border: 1.5px solid #4361ee; }
.btn-outline:hover { background: #eef1fd; }
.btn-danger  { background: #fff; color: #e63946; border: 1.5px solid #e63946; }
.btn-danger:hover  { background: #fdecea; }
.btn-sm { padding: 5px 12px; font-size: 13px; }

/* Layout 2 colonnes */
.layout { display: grid; grid-template-columns: 1fr 260px; gap: 20px; align-items: start; }

/* Section repos */
.section-title { font-size: 15px; font-weight: 600; margin-bottom: 14px; display: flex; align-items: center; justify-content: space-between; }
.repo-list { display: flex; flex-direction: column; gap: 12px; }
.repo-card { background: #fff; border-radius: 12px; padding: 16px 20px; border: 1.5px solid #e9ecef;
             display: flex; align-items: center; justify-content: space-between; transition: .15s; }
.repo-card:hover { border-color: #4361ee; }
.repo-card-left  { flex: 1; min-width: 0; }
.repo-card-left h3 { font-size: 15px; font-weight: 600; margin-bottom: 3px; }
.repo-card-left p  { font-size: 13px; color: #6c757d; }
.repo-card-meta { font-size: 12px; color: #9ca3af; margin-top: 6px; display: flex; gap: 12px; }
.repo-card-right { display: flex; gap: 8px; flex-shrink: 0; margin-left: 16px; }

/* Members sidebar */
.sidebar-card { background: #fff; border-radius: 12px; padding: 18px 20px; border: 1.5px solid #e9ecef; }
.sidebar-card h3 { font-size: 14px; font-weight: 600; margin-bottom: 14px; }
.member-item { display: flex; align-items: center; gap: 10px; padding: 6px 0;
               border-bottom: 1px solid #f3f4f6; }
.member-item:last-child { border-bottom: none; }
.avatar { width: 32px; height: 32px; border-radius: 50%; background: #eef1fd; display: flex;
          align-items: center; justify-content: center; font-size: 12px; font-weight: 700; color: #4361ee; flex-shrink: 0; }
.member-name { font-size: 13px; font-weight: 500; }
.member-role { font-size: 11px; color: #9ca3af; }
.badge-owner-sm { font-size: 10px; padding: 1px 7px; border-radius: 20px; background: #ede9fe; color: #5b21b6; }

/* Empty */
.empty-state { text-align: center; padding: 40px 20px; color: #9ca3af; background: #fff; border-radius: 12px; border: 1.5px solid #e9ecef; }
.empty-state .icon { font-size: 36px; margin-bottom: 8px; }

/* Modal */
.modal-backdrop { display: none; position: fixed; inset: 0; background: rgba(0,0,0,.45); z-index: 100; align-items: center; justify-content: center; }
.modal-backdrop.open { display: flex; }
.modal { background: #fff; border-radius: 14px; padding: 28px; width: 460px; max-width: 95vw; }
.modal h2 { font-size: 18px; font-weight: 700; margin-bottom: 20px; }
.form-group { margin-bottom: 14px; }
.form-group label { display: block; font-size: 13px; font-weight: 500; margin-bottom: 5px; color: #374151; }
.form-group input, .form-group textarea {
    width: 100%; padding: 9px 12px; border: 1.5px solid #e5e7eb; border-radius: 8px;
    font-size: 14px; outline: none; transition: .15s; font-family: inherit; }
.form-group input:focus, .form-group textarea:focus { border-color: #4361ee; }
.form-group textarea { resize: vertical; min-height: 70px; }
.modal-footer { display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px; }
.alert { padding: 10px 14px; border-radius: 8px; font-size: 13px; margin-bottom: 12px; display: none; }
.alert-error { background: #fee2e2; color: #991b1b; }
</style>
</head>
<body>
<div class="page-wrap">

    <div class="breadcrumb">
        <a href="index.php?page=collab">Groupes</a> / <?= htmlspecialchars($group->getNom()) ?>
    </div>

    <!-- Header -->
    <div class="group-header">
        <div class="group-header-left">
            <h1>📁 <?= htmlspecialchars($group->getNom()) ?></h1>
            <p><?= htmlspecialchars($group->getDescription() ?: 'Aucune description.') ?></p>
            <div class="group-meta-row">
                <span class="meta-chip chip-<?= $group->getVisibilite() ?>"><?= $group->getVisibilite() ?></span>
                <span style="font-size:13px;color:#6c757d;">Créé le <?= date('d/m/Y', strtotime($group->getDateCreation())) ?></span>
            </div>
        </div>
        <div class="group-header-actions">
            <?php if ($estMembre): ?>
                <?php if ($estOwner): ?>
                <button class="btn btn-danger btn-sm" onclick="deleteGroup(<?= $group->getIdGroup() ?>)">Supprimer</button>
                <?php else: ?>
                <button class="btn btn-danger btn-sm" onclick="leaveGroup(<?= $group->getIdGroup() ?>)">Quitter</button>
                <?php endif; ?>
                <button class="btn btn-primary btn-sm" onclick="document.getElementById('modal-repo').classList.add('open')">+ Nouveau dépôt</button>
            <?php else: ?>
                <button class="btn btn-primary btn-sm" onclick="joinGroup(<?= $group->getIdGroup() ?>)">Rejoindre</button>
            <?php endif; ?>
        </div>
    </div>

    <!-- Layout -->
    <div class="layout">
        <!-- Repos -->
        <div>
            <div class="section-title">
                <span>📦 Dépôts (<?= count($repos) ?>)</span>
            </div>

            <?php if (empty($repos)): ?>
                <div class="empty-state">
                    <div class="icon">📭</div>
                    <p>Aucun dépôt dans ce groupe.</p>
                    <?php if ($estMembre): ?>
                    <button class="btn btn-primary btn-sm" style="margin-top:12px;"
                            onclick="document.getElementById('modal-repo').classList.add('open')">Créer le premier dépôt</button>
                    <?php endif; ?>
                </div>
            <?php else: ?>
            <div class="repo-list">
                <?php foreach ($repos as $r): ?>
                <div class="repo-card">
                    <div class="repo-card-left">
                        <h3>📂 <?= htmlspecialchars($r['nom']) ?></h3>
                        <p><?= htmlspecialchars($r['description'] ?: 'Aucune description.') ?></p>
                        <div class="repo-card-meta">
                            <span>🌿 <?= $r['nb_branches'] ?> branche<?= $r['nb_branches'] > 1 ? 's' : '' ?></span>
                            <span>✅ <?= $r['nb_commits'] ?> commit<?= $r['nb_commits'] > 1 ? 's' : '' ?></span>
                        </div>
                    </div>
                    <div class="repo-card-right">
                        <a href="index.php?page=collab&action=repo&id=<?= $r['id_repo'] ?>" class="btn btn-primary btn-sm">Ouvrir</a>
                        <?php if ($estOwner): ?>
                        <button class="btn btn-danger btn-sm" onclick="deleteRepo(<?= $r['id_repo'] ?>)">Supprimer</button>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>

        <!-- Sidebar membres -->
        <div>
            <div class="sidebar-card">
                <h3>👥 Membres (<?= count($membres) ?>)</h3>
                <?php foreach ($membres as $m): ?>
                <div class="member-item">
                    <div class="avatar"><?= strtoupper(substr($m['user_prenom'] ?? 'U', 0, 1) . substr($m['user_nom'] ?? '', 0, 1)) ?></div>
                    <div>
                        <div class="member-name" style="display:flex;align-items:center;gap:6px;">
                            <?= htmlspecialchars(trim(($m['user_prenom'] ?? '') . ' ' . ($m['user_nom'] ?? ''))) ?: $m['email'] ?>
                            <?php if ($m['role'] === 'owner'): ?>
                            <span class="badge-owner-sm">owner</span>
                            <?php endif; ?>
                        </div>
                        <div class="member-role"><?= htmlspecialchars($m['email'] ?? '') ?></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

</div>

<!-- Modal : Créer un dépôt -->
<div class="modal-backdrop" id="modal-repo">
    <div class="modal">
        <h2>Nouveau dépôt</h2>
        <div class="alert alert-error" id="repo-error"></div>
        <div class="form-group">
            <label>Nom du dépôt *</label>
            <input type="text" id="repo-nom" placeholder="Ex: frontend-app" maxlength="100">
        </div>
        <div class="form-group">
            <label>Description</label>
            <textarea id="repo-desc" placeholder="À quoi sert ce dépôt ?"></textarea>
        </div>
        <div class="modal-footer">
            <button class="btn btn-outline" onclick="document.getElementById('modal-repo').classList.remove('open')">Annuler</button>
            <button class="btn btn-primary" onclick="submitCreateRepo()">Créer</button>
        </div>
    </div>
</div>

<script>
const GROUP_ID = <?= $group->getIdGroup() ?>;

function submitCreateRepo() {
    const nom  = document.getElementById('repo-nom').value.trim();
    const desc = document.getElementById('repo-desc').value.trim();
    const err  = document.getElementById('repo-error');
    err.style.display = 'none';
    if (!nom) { err.textContent = 'Le nom est requis.'; err.style.display = 'block'; return; }

    fetch('index.php?page=collab&action=create-repo', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: `id_group=${GROUP_ID}&nom=${encodeURIComponent(nom)}&description=${encodeURIComponent(desc)}`
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) location.href = 'index.php?page=collab&action=repo&id=' + data.id_repo;
        else { err.textContent = data.error || 'Erreur.'; err.style.display = 'block'; }
    });
}

function deleteRepo(id) {
    if (!confirm('Supprimer ce dépôt et tout son contenu ?')) return;
    fetch('index.php?page=collab&action=delete-repo', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'id_repo=' + id
    })
    .then(r => r.json())
    .then(data => { if (data.success) location.reload(); else alert(data.error); });
}

function joinGroup(id) {
    fetch('index.php?page=collab&action=join-group', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'id_group=' + id
    })
    .then(r => r.json())
    .then(data => { if (data.success) location.reload(); else alert(data.error); });
}

function leaveGroup(id) {
    if (!confirm('Quitter ce groupe ?')) return;
    fetch('index.php?page=collab&action=leave-group', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'id_group=' + id
    })
    .then(r => r.json())
    .then(data => { if (data.success) location.href = 'index.php?page=collab'; else alert(data.error); });
}

function deleteGroup(id) {
    if (!confirm('Supprimer définitivement ce groupe ?')) return;
    fetch('index.php?page=collab&action=delete-group', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'id_group=' + id
    })
    .then(r => r.json())
    .then(data => { if (data.success) location.href = 'index.php?page=collab'; else alert(data.error); });
}
</script>
</body>
</html>
