<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title><?= htmlspecialchars($repo->getNom()) ?> — FreelaSkill</title>
<style>
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'Segoe UI', sans-serif; background: #f5f6fa; color: #1a1a2e; }
.page-wrap { max-width: 1000px; margin: 0 auto; padding: 30px 20px; }
.breadcrumb { font-size: 13px; color: #9ca3af; margin-bottom: 20px; }
.breadcrumb a { color: #4361ee; text-decoration: none; }
.breadcrumb a:hover { text-decoration: underline; }

.repo-header { background: #fff; border-radius: 14px; padding: 22px 26px; margin-bottom: 24px;
               border: 1.5px solid #e9ecef; display: flex; align-items: center; justify-content: space-between; gap: 16px; }
.repo-header-left h1 { font-size: 20px; font-weight: 700; }
.repo-header-left p  { font-size: 13px; color: #6c757d; margin-top: 4px; }
.repo-header-left .default-branch { font-size: 12px; color: #4361ee; margin-top: 6px; }

.btn { display: inline-flex; align-items: center; gap: 6px; padding: 9px 18px; border-radius: 8px;
       border: none; cursor: pointer; font-size: 14px; font-weight: 500; text-decoration: none; transition: .15s; }
.btn-primary { background: #4361ee; color: #fff; }
.btn-primary:hover { background: #3451d1; }
.btn-outline { background: #fff; color: #4361ee; border: 1.5px solid #4361ee; }
.btn-outline:hover { background: #eef1fd; }
.btn-danger  { background: #fff; color: #e63946; border: 1.5px solid #e63946; }
.btn-danger:hover  { background: #fdecea; }
.btn-sm { padding: 5px 12px; font-size: 13px; }

.section-title { font-size: 15px; font-weight: 600; margin-bottom: 14px; display: flex; align-items: center; justify-content: space-between; }
.branch-list { display: flex; flex-direction: column; gap: 10px; }
.branch-card { background: #fff; border-radius: 12px; padding: 16px 20px; border: 1.5px solid #e9ecef;
               display: flex; align-items: center; justify-content: space-between; transition: .15s; }
.branch-card:hover { border-color: #4361ee; }
.branch-card.is-default { border-left: 4px solid #4361ee; }
.branch-left h3 { font-size: 15px; font-weight: 600; display: flex; align-items: center; gap: 8px; }
.branch-left p  { font-size: 12px; color: #9ca3af; margin-top: 4px; }
.badge-default { font-size: 10px; padding: 2px 8px; border-radius: 20px; background: #dbeafe; color: #1e40af; }
.branch-right { display: flex; gap: 8px; flex-shrink: 0; }

.empty-state { text-align: center; padding: 40px; color: #9ca3af; background: #fff;
               border-radius: 12px; border: 1.5px solid #e9ecef; }
.empty-state .icon { font-size: 36px; margin-bottom: 8px; }

.modal-backdrop { display: none; position: fixed; inset: 0; background: rgba(0,0,0,.45); z-index: 100; align-items: center; justify-content: center; }
.modal-backdrop.open { display: flex; }
.modal { background: #fff; border-radius: 14px; padding: 28px; width: 440px; max-width: 95vw; }
.modal h2 { font-size: 18px; font-weight: 700; margin-bottom: 20px; }
.form-group { margin-bottom: 14px; }
.form-group label { display: block; font-size: 13px; font-weight: 500; margin-bottom: 5px; color: #374151; }
.form-group input { width: 100%; padding: 9px 12px; border: 1.5px solid #e5e7eb; border-radius: 8px;
                    font-size: 14px; outline: none; transition: .15s; font-family: inherit; }
.form-group input:focus { border-color: #4361ee; }
.form-hint { font-size: 11px; color: #9ca3af; margin-top: 4px; }
.modal-footer { display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px; }
.alert { padding: 10px 14px; border-radius: 8px; font-size: 13px; margin-bottom: 12px; display: none; }
.alert-error { background: #fee2e2; color: #991b1b; }
</style>
</head>
<body>
<div class="page-wrap">

    <div class="breadcrumb">
        <a href="index.php?page=collab">Groupes</a> /
        <a href="index.php?page=collab&action=group&id=<?= $repo->getIdGroup() ?>">Groupe</a> /
        <?= htmlspecialchars($repo->getNom()) ?>
    </div>

    <!-- Header repo -->
    <div class="repo-header">
        <div class="repo-header-left">
            <h1>📂 <?= htmlspecialchars($repo->getNom()) ?></h1>
            <p><?= htmlspecialchars($repo->getDescription() ?: 'Aucune description.') ?></p>
            <div class="default-branch">🌿 Branche principale : <strong><?= htmlspecialchars($repo->getBrancheDefaut()) ?></strong></div>
        </div>
        <div style="display:flex;gap:8px;flex-shrink:0;">
            <button class="btn btn-primary btn-sm" onclick="document.getElementById('modal-branch').classList.add('open')">+ Nouvelle branche</button>
            <?php if ($estOwner): ?>
            <button class="btn btn-danger btn-sm" onclick="deleteRepo(<?= $repo->getIdRepo() ?>, <?= $repo->getIdGroup() ?>)">Supprimer</button>
            <?php endif; ?>
        </div>
    </div>

    <!-- Branches -->
    <div class="section-title">
        <span>🌿 Branches (<?= count($branches) ?>)</span>
    </div>

    <?php if (empty($branches)): ?>
    <div class="empty-state">
        <div class="icon">🌱</div>
        <p>Aucune branche trouvée.</p>
    </div>
    <?php else: ?>
    <div class="branch-list">
        <?php foreach ($branches as $b): ?>
        <div class="branch-card <?= $b['is_default'] ? 'is-default' : '' ?>">
            <div class="branch-left">
                <h3>
                    🌿 <?= htmlspecialchars($b['nom']) ?>
                    <?php if ($b['is_default']): ?>
                    <span class="badge-default">principale</span>
                    <?php endif; ?>
                </h3>
                <p>
                    <?= $b['nb_commits'] ?> commit<?= $b['nb_commits'] > 1 ? 's' : '' ?>
                    <?php if ($b['last_commit_date']): ?>
                    · Dernier : <?= date('d/m/Y H:i', strtotime($b['last_commit_date'])) ?>
                    — <?= htmlspecialchars(mb_strimwidth($b['last_commit_msg'] ?? '', 0, 50, '…')) ?>
                    <?php endif; ?>
                </p>
            </div>
            <div class="branch-right">
                <a href="index.php?page=collab&action=branch&id=<?= $b['id_branch'] ?>" class="btn btn-primary btn-sm">Ouvrir</a>
                <?php if ($estOwner && !$b['is_default']): ?>
                <button class="btn btn-danger btn-sm" onclick="deleteBranch(<?= $b['id_branch'] ?>)">Supprimer</button>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

</div>

<!-- Modal : Créer une branche -->
<div class="modal-backdrop" id="modal-branch">
    <div class="modal">
        <h2>Nouvelle branche</h2>
        <div class="alert alert-error" id="branch-error"></div>
        <div class="form-group">
            <label>Nom de la branche *</label>
            <input type="text" id="branch-nom" placeholder="Ex: feature-login" maxlength="100">
            <div class="form-hint">Lettres, chiffres, tirets et underscores uniquement.</div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-outline" onclick="document.getElementById('modal-branch').classList.remove('open')">Annuler</button>
            <button class="btn btn-primary" onclick="submitCreateBranch()">Créer la branche</button>
        </div>
    </div>
</div>

<script>
const REPO_ID  = <?= $repo->getIdRepo() ?>;
const GROUP_ID = <?= $repo->getIdGroup() ?>;

function submitCreateBranch() {
    const nom = document.getElementById('branch-nom').value.trim();
    const err = document.getElementById('branch-error');
    err.style.display = 'none';
    if (!nom) { err.textContent = 'Le nom est requis.'; err.style.display = 'block'; return; }

    fetch('index.php?page=collab&action=create-branch', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: `id_repo=${REPO_ID}&nom=${encodeURIComponent(nom)}`
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) location.href = 'index.php?page=collab&action=branch&id=' + data.id_branch;
        else { err.textContent = data.error || 'Erreur.'; err.style.display = 'block'; }
    });
}

function deleteBranch(id) {
    if (!confirm('Supprimer cette branche et tous ses commits ?')) return;
    fetch('index.php?page=collab&action=delete-branch', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'id_branch=' + id
    })
    .then(r => r.json())
    .then(data => { if (data.success) location.reload(); else alert(data.error); });
}

function deleteRepo(id, gid) {
    if (!confirm('Supprimer ce dépôt et tout son contenu ?')) return;
    fetch('index.php?page=collab&action=delete-repo', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'id_repo=' + id
    })
    .then(r => r.json())
    .then(data => { if (data.success) location.href = 'index.php?page=collab&action=group&id=' + gid; else alert(data.error); });
}
</script>
</body>
</html>
